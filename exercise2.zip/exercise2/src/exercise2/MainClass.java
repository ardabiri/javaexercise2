package exercise2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

// For part three
class accountscomparetor implements java.util.Comparator<Account>{
	@Override
	public int compare(Account a, Account b) {
		return a.getBalance() - b.getBalance();
	}
}

public class MainClass {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account account1 = new Account("saving", "01", 10);
		Account account2 = new Account("saving", "01", 20);
		Account account3 = new Account("saving", "02", 15);
		Account account4 = new Account("current", "02", 30);
		Account account5 = new Account("current", "01", 30);
		Account account6 = new Account("current", "01", 40);
		Account account7 = new Account("saving", "02", 48);
		Account account8 = new Account("current", "02", 17);
		Account account9 = new Account("current", "03", 35);
		Account account10 = new Account("saving", "03", 26);
		
		
		// First part
		List<Account> accounts = new ArrayList<>();
		accounts.add(account1);
		accounts.add(account2);
		accounts.add(account3);
		accounts.add(account4);
		accounts.add(account5);
		accounts.add(account6);
		accounts.add(account7);
		accounts.add(account8);
		accounts.add(account9);
		accounts.add(account10);
		
		
		// Second part
		for (Account account : accounts) {
			System.out.println("This is a " + account.getName() + " account in branch code " + account.getBranch() + " with a balance of " + account.getBalance() + "$");
		}
		
		// Third part
		Collections.sort(accounts, new accountscomparetor());
		System.out.println(accounts);
		
		// Fourth part
		System.out.println(accounts.reversed());
		
		// Fifth part
		Map<String, Account> accountmap = new HashMap<>();
		for(int i =0; i<accounts.size();i++) {
			accountmap.put("p"+i, accounts.get(i));
		}
		
		// Sixth part
		accountmap.forEach((key,value)->System.out.println(key+""+value));
		
		// Seventh part
		Set<String> delset = new HashSet<>();
		accountmap.forEach((key,value)->{if (value.getBranch() == "02") {
			delset.add(key);
		}});
		accountmap.keySet().removeAll(delset);
		accountmap.forEach((key,value)->System.out.println(key+""+value));
		
		
//		System.out.println(accounts.get(2));
//		System.out.println(accounts.size());
		
		
		

	}

}
